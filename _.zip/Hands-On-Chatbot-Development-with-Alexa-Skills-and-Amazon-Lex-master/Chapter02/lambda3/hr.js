module.exports = {
    calculateHR: (age) => {
        return 220 - age;
    }
}